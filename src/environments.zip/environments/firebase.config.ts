const FirebaseConfig = {
    apiKey: "AIzaSyDhC5o1zOGNUY3VYDYMjXfqLc8n6VliFRA",
    authDomain: "radio-lux.firebaseapp.com",
    databaseURL: "https://radio-lux.firebaseio.com",
    projectId: "radio-lux",
    storageBucket: "radio-lux.appspot.com",
    messagingSenderId: "606243873934"
  };

  export default FirebaseConfig;