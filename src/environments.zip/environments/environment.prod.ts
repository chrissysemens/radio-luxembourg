import FirebaseConfig from './firebase.config';

export const environment = {
  production: true,
  firebaseConfig: FirebaseConfig
};
