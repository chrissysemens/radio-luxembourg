export const TokenConfig = {
    tokenUrl: 'https://rl-auth.herokuapp.com/login',
    refreshUrl: 'https://rl-auth.herokuapp.com/refresh'
}