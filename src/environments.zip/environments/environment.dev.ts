import FirebaseConfig  from './firebase.config';

export const environment = {
    production: false,
    firebaseConfig: FirebaseConfig
  };